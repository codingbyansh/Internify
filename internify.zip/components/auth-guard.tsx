"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

interface AuthGuardProps {
  children: React.ReactNode
  requiredRole?: "student" | "recruiter" | "admin"
}

export function AuthGuard({ children, requiredRole }: AuthGuardProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Simulate auth check - in real app, this would check JWT/session
    const checkAuth = () => {
      const mockUser = localStorage.getItem("internify_user")
      if (mockUser) {
        const user = JSON.parse(mockUser)
        setIsAuthenticated(true)
        setUserRole(user.role)
      } else {
        setIsAuthenticated(false)
        router.push("/auth")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  useEffect(() => {
    if (!isLoading && isAuthenticated && requiredRole && userRole !== requiredRole) {
      // Redirect to appropriate dashboard if role doesn't match
      if (userRole === "student") {
        router.push("/dashboard/student")
      } else if (userRole === "recruiter") {
        router.push("/dashboard/recruiter")
      } else if (userRole === "admin") {
        router.push("/dashboard/admin")
      }
    }
  }, [isAuthenticated, userRole, requiredRole, router, isLoading])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  if (requiredRole && userRole !== requiredRole) {
    return null
  }

  return <>{children}</>
}
