export interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  role: "student" | "recruiter" | "admin"
  avatar?: string
  createdAt: string
  profile?: {
    phone?: string
    location?: string
    bio?: string
    college?: string
    degree?: string
    year?: string
    gpa?: string
    linkedin?: string
    github?: string
    portfolio?: string
    skills?: string[]
  }
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}

// Mock authentication functions - in real app, these would call your backend API
export const authService = {
  async login(email: string, password: string, role: "student" | "recruiter"): Promise<User> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      firstName: "John",
      lastName: "Doe",
      role,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
      createdAt: new Date().toISOString(),
    }

    localStorage.setItem("internify_user", JSON.stringify(mockUser))
    localStorage.setItem("internify_token", "mock-jwt-token")

    return mockUser
  },

  async signup(userData: {
    email: string
    password: string
    firstName: string
    lastName: string
    role: "student" | "recruiter"
  }): Promise<User> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      role: userData.role,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.email}`,
      createdAt: new Date().toISOString(),
    }

    localStorage.setItem("internify_user", JSON.stringify(mockUser))
    localStorage.setItem("internify_token", "mock-jwt-token")

    return mockUser
  },

  async logout(): Promise<void> {
    localStorage.removeItem("internify_user")
    localStorage.removeItem("internify_token")
  },

  getCurrentUser(): User | null {
    if (typeof window === "undefined") return null

    const userData = localStorage.getItem("internify_user")
    return userData ? JSON.parse(userData) : null
  },

  getToken(): string | null {
    if (typeof window === "undefined") return null

    return localStorage.getItem("internify_token")
  },

  async updateProfile(profileData: any): Promise<User> {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const currentUser = this.getCurrentUser()
    if (!currentUser) {
      throw new Error("No user logged in")
    }

    const updatedUser: User = {
      ...currentUser,
      firstName: profileData.firstName || currentUser.firstName,
      lastName: profileData.lastName || currentUser.lastName,
      email: profileData.email || currentUser.email,
      profile: {
        ...currentUser.profile,
        ...profileData,
      },
    }

    localStorage.setItem("internify_user", JSON.stringify(updatedUser))
    return updatedUser
  },
}
