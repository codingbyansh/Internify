"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  ArrowLeft,
  MapPin,
  DollarSign,
  Clock,
  Building2,
  Users,
  Star,
  Heart,
  Send,
  CheckCircle,
  Calendar,
  Globe,
  Award,
  Target,
  BookmarkPlus,
  Share2,
  AlertCircle,
} from "lucide-react"
import Link from "next/link"
import { authService } from "@/lib/auth"

// Mock internship data - in real app, this would be fetched from API
const mockInternshipData = {
  "1": {
    id: "1",
    title: "Frontend Developer Intern",
    company: "TechCorp",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
    location: "Bangalore, India",
    stipend: "₹25,000/month",
    duration: "3 months",
    type: "Remote",
    skills: ["React", "JavaScript", "CSS", "TypeScript", "Git"],
    aiMatch: 95,
    description:
      "Join our dynamic frontend team and work on cutting-edge web applications using React and modern JavaScript frameworks. You'll collaborate with senior developers to build user-friendly interfaces and contribute to our product development cycle.",
    posted: "2 days ago",
    applicants: 45,
    companySize: "500-1000 employees",
    industry: "Technology",
    website: "https://techcorp.com",
    companyDescription:
      "TechCorp is a leading technology company specializing in innovative software solutions for businesses worldwide. We're committed to creating products that make a difference and fostering a culture of continuous learning and growth.",
    requirements: [
      "Currently pursuing Bachelor's/Master's in Computer Science or related field",
      "Strong knowledge of HTML, CSS, and JavaScript",
      "Experience with React.js and modern frontend frameworks",
      "Understanding of responsive web design principles",
      "Good communication skills and team collaboration",
      "Passion for learning new technologies",
    ],
    responsibilities: [
      "Develop and maintain user-facing web applications",
      "Collaborate with design team to implement UI/UX designs",
      "Write clean, maintainable, and efficient code",
      "Participate in code reviews and team meetings",
      "Debug and troubleshoot frontend issues",
      "Stay updated with latest frontend technologies and best practices",
    ],
    benefits: [
      "Competitive stipend and performance bonuses",
      "Mentorship from senior developers",
      "Flexible working hours",
      "Learning and development opportunities",
      "Certificate of completion",
      "Potential for full-time offer",
    ],
    applicationDeadline: "2025-01-15",
    startDate: "2025-02-01",
  },
}

function InternshipDetails() {
  const params = useParams()
  const router = useRouter()
  const [isApplying, setIsApplying] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [applicationSubmitted, setApplicationSubmitted] = useState(false)
  const [coverLetter, setCoverLetter] = useState("")
  const [resumeFile, setResumeFile] = useState<File | null>(null)

  const internshipId = params.id as string
  const internship = mockInternshipData[internshipId as keyof typeof mockInternshipData]
  const user = authService.getCurrentUser()

  if (!internship) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Internship Not Found</h1>
          <p className="text-muted-foreground mb-4">The internship you're looking for doesn't exist.</p>
          <Link href="/dashboard/student">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handleApply = async () => {
    setIsApplying(true)
    // Simulate API call
    setTimeout(() => {
      setIsApplying(false)
      setApplicationSubmitted(true)
    }, 2000)
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${internship.title} at ${internship.company}`,
        text: `Check out this internship opportunity: ${internship.title} at ${internship.company}`,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
    }
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </Button>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSave}
                className={isSaved ? "bg-accent/10 text-accent border-accent/20" : ""}
              >
                {isSaved ? <Heart className="w-4 h-4 mr-2 fill-current" /> : <BookmarkPlus className="w-4 h-4 mr-2" />}
                {isSaved ? "Saved" : "Save"}
              </Button>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Main Internship Info */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="flex items-start space-x-6 mb-6">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={internship.logo || "/placeholder.svg"} />
                  <AvatarFallback className="text-lg">{internship.company[0]}</AvatarFallback>
                </Avatar>

                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h1 className="text-3xl font-bold text-balance">{internship.title}</h1>
                    <Badge
                      className={`${
                        internship.aiMatch >= 90
                          ? "bg-green-100 text-green-800 border-green-200"
                          : internship.aiMatch >= 80
                            ? "bg-blue-100 text-blue-800 border-blue-200"
                            : "bg-yellow-100 text-yellow-800 border-yellow-200"
                      }`}
                    >
                      <Star className="w-3 h-3 mr-1" />
                      {internship.aiMatch}% AI Match
                    </Badge>
                  </div>

                  <h2 className="text-xl text-muted-foreground mb-4">{internship.company}</h2>

                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.location}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.stipend}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Building2 className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.type}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.companySize}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Globe className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.industry}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Fit Score */}
              <div className="bg-muted/30 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold flex items-center space-x-2">
                    <Target className="w-4 h-4 text-primary" />
                    <span>AI Fit Score</span>
                  </h3>
                  <span className="text-2xl font-bold text-primary">{internship.aiMatch}%</span>
                </div>
                <Progress value={internship.aiMatch} className="mb-2" />
                <p className="text-sm text-muted-foreground">
                  Based on your profile, skills, and preferences, this internship is an excellent match for you!
                </p>
              </div>

              {/* Skills */}
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {internship.skills.map((skill) => (
                    <Badge key={skill} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Application Deadline */}
              <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
                <Calendar className="w-4 h-4" />
                <span>Application Deadline: {new Date(internship.applicationDeadline).toLocaleDateString()}</span>
                <span>•</span>
                <span>Start Date: {new Date(internship.startDate).toLocaleDateString()}</span>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-4">
                {applicationSubmitted ? (
                  <div className="flex items-center space-x-2 text-green-600">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Application Submitted!</span>
                  </div>
                ) : (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="lg" className="px-8">
                        <Send className="w-4 h-4 mr-2" />
                        Apply Now
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Apply for {internship.title}</DialogTitle>
                        <DialogDescription>
                          Complete your application for this internship at {internship.company}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="resume">Resume/CV *</Label>
                          <Input
                            id="resume"
                            type="file"
                            accept=".pdf,.doc,.docx"
                            onChange={(e) => setResumeFile(e.target.files?.[0] || null)}
                            className="mt-1"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Upload your resume in PDF, DOC, or DOCX format
                          </p>
                        </div>
                        <div>
                          <Label htmlFor="coverLetter">Cover Letter</Label>
                          <Textarea
                            id="coverLetter"
                            placeholder="Tell us why you're interested in this internship and what makes you a great fit..."
                            value={coverLetter}
                            onChange={(e) => setCoverLetter(e.target.value)}
                            rows={6}
                            className="mt-1"
                          />
                          <p className="text-xs text-muted-foreground mt-1">Optional but recommended. Max 500 words.</p>
                        </div>
                        <div className="flex items-start space-x-2 p-3 bg-blue-50 rounded-lg">
                          <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                          <div className="text-sm">
                            <p className="font-medium text-blue-900">Application Tips:</p>
                            <ul className="text-blue-700 mt-1 space-y-1">
                              <li>• Highlight relevant projects and experience</li>
                              <li>• Mention specific skills that match the requirements</li>
                              <li>• Show enthusiasm for the company and role</li>
                            </ul>
                          </div>
                        </div>
                        <div className="flex justify-end space-x-3">
                          <DialogTrigger asChild>
                            <Button variant="outline">Cancel</Button>
                          </DialogTrigger>
                          <Button onClick={handleApply} disabled={isApplying || !resumeFile}>
                            {isApplying ? "Submitting..." : "Submit Application"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
                <Button variant="outline" size="lg" onClick={handleSave}>
                  {isSaved ? (
                    <Heart className="w-4 h-4 mr-2 fill-current" />
                  ) : (
                    <BookmarkPlus className="w-4 h-4 mr-2" />
                  )}
                  Save for Later
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Detailed Information */}
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-6">
              {/* Job Description */}
              <Card>
                <CardHeader>
                  <CardTitle>About the Role</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{internship.description}</p>
                </CardContent>
              </Card>

              {/* Responsibilities */}
              <Card>
                <CardHeader>
                  <CardTitle>Key Responsibilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {internship.responsibilities.map((responsibility, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{responsibility}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Requirements */}
              <Card>
                <CardHeader>
                  <CardTitle>Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {internship.requirements.map((requirement, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Award className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Benefits */}
              <Card>
                <CardHeader>
                  <CardTitle>What We Offer</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {internship.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Star className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Company Info */}
              <Card>
                <CardHeader>
                  <CardTitle>About {internship.company}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">{internship.companyDescription}</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.companySize}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Building2 className="w-4 h-4 text-muted-foreground" />
                      <span>{internship.industry}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Globe className="w-4 h-4 text-muted-foreground" />
                      <a
                        href={internship.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        Visit Website
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Application Stats */}
              <Card>
                <CardHeader>
                  <CardTitle>Application Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Total Applicants</span>
                      <span className="font-medium">{internship.applicants}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Posted</span>
                      <span className="font-medium">{internship.posted}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Your Match</span>
                      <Badge
                        className={`${
                          internship.aiMatch >= 90
                            ? "bg-green-100 text-green-800 border-green-200"
                            : "bg-blue-100 text-blue-800 border-blue-200"
                        }`}
                      >
                        {internship.aiMatch}%
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Similar Internships */}
              <Card>
                <CardHeader>
                  <CardTitle>Similar Internships</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer">
                      <h4 className="font-medium text-sm">Backend Developer Intern</h4>
                      <p className="text-xs text-muted-foreground">CloudTech • ₹28,000/month</p>
                      <Badge className="mt-1 text-xs bg-blue-100 text-blue-800 border-blue-200">91% match</Badge>
                    </div>
                    <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer">
                      <h4 className="font-medium text-sm">Full Stack Intern</h4>
                      <p className="text-xs text-muted-foreground">StartupXYZ • ₹22,000/month</p>
                      <Badge className="mt-1 text-xs bg-yellow-100 text-yellow-800 border-yellow-200">85% match</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}

export default InternshipDetails
