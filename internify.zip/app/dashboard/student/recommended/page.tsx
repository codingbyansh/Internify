"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Brain, MapPin, DollarSign, Clock, Building2, Star, Send, Heart, RefreshCw } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

const mockRecommendations = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "TechCorp",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
    location: "Bangalore, India",
    stipend: "₹25,000/month",
    duration: "3 months",
    type: "Remote",
    skills: ["React", "JavaScript", "CSS"],
    aiMatch: 95,
    description: "Work on cutting-edge web applications using React and modern JavaScript frameworks.",
    posted: "2 days ago",
    applicants: 45,
    matchReasons: ["Strong React skills", "JavaScript expertise", "Remote work preference"],
  },
  {
    id: "2",
    title: "Full Stack Developer Intern",
    company: "StartupHub",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=startuphub",
    location: "Bangalore, India",
    stipend: "₹28,000/month",
    duration: "4 months",
    type: "Hybrid",
    skills: ["React", "Node.js", "MongoDB"],
    aiMatch: 92,
    description: "Build end-to-end web applications in a fast-paced startup environment.",
    posted: "1 day ago",
    applicants: 38,
    matchReasons: ["Full stack skills", "Startup experience", "Node.js proficiency"],
  },
  {
    id: "3",
    title: "Backend Developer Intern",
    company: "CloudTech",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=cloudtech",
    location: "Hyderabad, India",
    stipend: "₹28,000/month",
    duration: "5 months",
    type: "Remote",
    skills: ["Node.js", "MongoDB", "AWS"],
    aiMatch: 91,
    description: "Build scalable backend systems and APIs for cloud-based applications.",
    posted: "1 week ago",
    applicants: 67,
    matchReasons: ["Backend expertise", "Cloud technologies", "API development"],
  },
  {
    id: "4",
    title: "Data Science Intern",
    company: "DataFlow",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=dataflow",
    location: "Mumbai, India",
    stipend: "₹30,000/month",
    duration: "6 months",
    type: "Hybrid",
    skills: ["Python", "Machine Learning", "SQL"],
    aiMatch: 88,
    description: "Analyze large datasets and build predictive models for business insights.",
    posted: "1 day ago",
    applicants: 32,
    matchReasons: ["Python skills", "Data analysis", "ML knowledge"],
  },
]

function RecommendedPage() {
  const router = useRouter()
  const [recommendations, setRecommendations] = useState(mockRecommendations)
  const [sortBy, setSortBy] = useState("match")
  const [savedInternships, setSavedInternships] = useState<string[]>([])
  const [isRefreshing, setIsRefreshing] = useState(false)

  const refreshRecommendations = async () => {
    setIsRefreshing(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsRefreshing(false)
  }

  const handleSaveInternship = (internshipId: string) => {
    setSavedInternships((prev) =>
      prev.includes(internshipId) ? prev.filter((id) => id !== internshipId) : [...prev, internshipId],
    )
  }

  const getSortedRecommendations = () => {
    const sorted = [...recommendations]
    switch (sortBy) {
      case "match":
        return sorted.sort((a, b) => b.aiMatch - a.aiMatch)
      case "recent":
        return sorted.sort((a, b) => new Date(b.posted).getTime() - new Date(a.posted).getTime())
      case "stipend":
        return sorted.sort((a, b) => {
          const aStipend = Number.parseInt(a.stipend.replace(/[^\d]/g, ""))
          const bStipend = Number.parseInt(b.stipend.replace(/[^\d]/g, ""))
          return bStipend - aStipend
        })
      default:
        return sorted
    }
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold flex items-center space-x-2">
                  <Brain className="w-8 h-8 text-primary" />
                  <span>AI Recommendations</span>
                </h1>
                <p className="text-muted-foreground mt-1">Personalized internship matches based on your profile</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="match">Best Match</SelectItem>
                  <SelectItem value="recent">Most Recent</SelectItem>
                  <SelectItem value="stipend">Highest Stipend</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={refreshRecommendations} disabled={isRefreshing}>
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "Refreshing..." : "Refresh"}
              </Button>
            </div>
          </div>

          {/* AI Insights */}
          <Card className="mb-6 bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">AI Insights</h3>
                  <p className="text-muted-foreground mb-3">
                    Based on your profile, skills, and preferences, we've found {recommendations.length} highly relevant
                    internships for you.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">React Developer</Badge>
                    <Badge variant="secondary">Remote Preferred</Badge>
                    <Badge variant="secondary">Bangalore Location</Badge>
                    <Badge variant="secondary">3-6 Month Duration</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <div className="grid gap-6">
            {getSortedRecommendations().map((internship) => (
              <Card key={internship.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex space-x-4 flex-1">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={internship.logo || "/placeholder.svg"} />
                        <AvatarFallback>{internship.company[0]}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-xl font-semibold">{internship.title}</h3>
                          <Badge
                            className={`${
                              internship.aiMatch >= 90
                                ? "bg-green-100 text-green-800 border-green-200"
                                : internship.aiMatch >= 80
                                  ? "bg-blue-100 text-blue-800 border-blue-200"
                                  : "bg-yellow-100 text-yellow-800 border-yellow-200"
                            }`}
                          >
                            <Star className="w-3 h-3 mr-1" />
                            {internship.aiMatch}% match
                          </Badge>
                        </div>

                        <p className="text-muted-foreground mb-3">{internship.company}</p>

                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                          <div className="flex items-center space-x-1">
                            <MapPin className="w-4 h-4" />
                            <span>{internship.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <DollarSign className="w-4 h-4" />
                            <span>{internship.stipend}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{internship.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Building2 className="w-4 h-4" />
                            <span>{internship.type}</span>
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground mb-3">{internship.description}</p>

                        <div className="flex flex-wrap gap-2 mb-3">
                          {internship.skills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>

                        {/* Match Reasons */}
                        <div className="mb-3">
                          <p className="text-sm font-medium text-primary mb-1">Why this matches you:</p>
                          <div className="flex flex-wrap gap-1">
                            {internship.matchReasons.map((reason, index) => (
                              <Badge
                                key={index}
                                variant="outline"
                                className="text-xs bg-primary/5 text-primary border-primary/20"
                              >
                                {reason}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Posted {internship.posted}</span>
                          <span>{internship.applicants} applicants</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2 ml-4">
                      <Link href={`/internship/${internship.id}`}>
                        <Button size="sm" className="w-full">
                          <Send className="w-4 h-4 mr-1" />
                          Apply Now
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSaveInternship(internship.id)}
                        className={`w-full ${
                          savedInternships.includes(internship.id) ? "bg-accent/10 text-accent border-accent/20" : ""
                        }`}
                      >
                        {savedInternships.includes(internship.id) ? (
                          <Heart className="w-4 h-4 mr-1 fill-current" />
                        ) : (
                          <Heart className="w-4 h-4 mr-1" />
                        )}
                        {savedInternships.includes(internship.id) ? "Saved" : "Save"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}

export default RecommendedPage
