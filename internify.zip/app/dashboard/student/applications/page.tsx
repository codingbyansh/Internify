"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Send, Clock, CheckCircle, XCircle, Calendar, Building2, MapPin } from "lucide-react"
import { useRouter } from "next/navigation"

const mockApplications = [
  {
    id: "1",
    internship: {
      title: "Frontend Developer Intern",
      company: "TechCorp",
      logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
      location: "Bangalore, India",
    },
    status: "interview",
    appliedDate: "2024-01-15",
    lastUpdate: "2024-01-20",
    interviewDate: "2024-01-25",
    notes: "Technical interview scheduled",
  },
  {
    id: "2",
    internship: {
      title: "Data Science Intern",
      company: "DataFlow",
      logo: "https://api.dicebear.com/7.x/shapes/svg?seed=dataflow",
      location: "Mumbai, India",
    },
    status: "accepted",
    appliedDate: "2024-01-10",
    lastUpdate: "2024-01-22",
    offerDate: "2024-01-22",
    notes: "Offer received! Respond by Jan 30",
  },
  {
    id: "3",
    internship: {
      title: "UI/UX Design Intern",
      company: "DesignStudio",
      logo: "https://api.dicebear.com/7.x/shapes/svg?seed=designstudio",
      location: "Delhi, India",
    },
    status: "pending",
    appliedDate: "2024-01-18",
    lastUpdate: "2024-01-18",
    notes: "Application under review",
  },
  {
    id: "4",
    internship: {
      title: "Backend Developer Intern",
      company: "CloudTech",
      logo: "https://api.dicebear.com/7.x/shapes/svg?seed=cloudtech",
      location: "Hyderabad, India",
    },
    status: "rejected",
    appliedDate: "2024-01-05",
    lastUpdate: "2024-01-12",
    notes: "Position filled",
  },
]

function ApplicationsPage() {
  const router = useRouter()
  const [applications] = useState(mockApplications)

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />
      case "interview":
        return <Calendar className="w-4 h-4 text-blue-600" />
      case "accepted":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case "rejected":
        return <XCircle className="w-4 h-4 text-red-600" />
      default:
        return <Clock className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "interview":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "accepted":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const filterApplications = (status?: string) => {
    if (!status) return applications
    return applications.filter((app) => app.status === status)
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold flex items-center space-x-2">
                  <Send className="w-8 h-8 text-primary" />
                  <span>Applications</span>
                </h1>
                <p className="text-muted-foreground mt-1">Track your internship applications and their status</p>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold">{applications.length}</div>
                <p className="text-sm text-muted-foreground">Total Applications</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold text-yellow-600">{filterApplications("pending").length}</div>
                <p className="text-sm text-muted-foreground">Pending</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold text-blue-600">{filterApplications("interview").length}</div>
                <p className="text-sm text-muted-foreground">Interviews</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-2xl font-bold text-green-600">{filterApplications("accepted").length}</div>
                <p className="text-sm text-muted-foreground">Offers</p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Applications</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="interview">Interviews</TabsTrigger>
              <TabsTrigger value="accepted">Offers</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              {applications.map((application) => (
                <Card key={application.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex space-x-4 flex-1">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={application.internship.logo || "/placeholder.svg"} />
                          <AvatarFallback>{application.internship.company[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-xl font-semibold">{application.internship.title}</h3>
                            <Badge className={getStatusColor(application.status)}>
                              {getStatusIcon(application.status)}
                              <span className="ml-1 capitalize">{application.status}</span>
                            </Badge>
                          </div>
                          <p className="text-muted-foreground mb-2">{application.internship.company}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                            <div className="flex items-center space-x-1">
                              <MapPin className="w-4 h-4" />
                              <span>{application.internship.location}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Building2 className="w-4 h-4" />
                              <span>Applied: {new Date(application.appliedDate).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{application.notes}</p>
                          {application.interviewDate && (
                            <div className="mt-2 p-2 bg-blue-50 rounded-lg">
                              <p className="text-sm text-blue-800">
                                <Calendar className="w-4 h-4 inline mr-1" />
                                Interview: {new Date(application.interviewDate).toLocaleDateString()}
                              </p>
                            </div>
                          )}
                          {application.offerDate && (
                            <div className="mt-2 p-2 bg-green-50 rounded-lg">
                              <p className="text-sm text-green-800">
                                <CheckCircle className="w-4 h-4 inline mr-1" />
                                Offer received: {new Date(application.offerDate).toLocaleDateString()}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                        {application.status === "accepted" && <Button size="sm">Respond to Offer</Button>}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            {["pending", "interview", "accepted", "rejected"].map((status) => (
              <TabsContent key={status} value={status} className="space-y-4">
                {filterApplications(status).map((application) => (
                  <Card key={application.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex space-x-4 flex-1">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={application.internship.logo || "/placeholder.svg"} />
                            <AvatarFallback>{application.internship.company[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold">{application.internship.title}</h3>
                              <Badge className={getStatusColor(application.status)}>
                                {getStatusIcon(application.status)}
                                <span className="ml-1 capitalize">{application.status}</span>
                              </Badge>
                            </div>
                            <p className="text-muted-foreground mb-2">{application.internship.company}</p>
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{application.internship.location}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Building2 className="w-4 h-4" />
                                <span>Applied: {new Date(application.appliedDate).toLocaleDateString()}</span>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">{application.notes}</p>
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {filterApplications(status).length === 0 && (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Send className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No {status} applications</h3>
                      <p className="text-muted-foreground">You don't have any {status} applications yet.</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}

export default ApplicationsPage
