"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ArrowLeft,
  Download,
  Eye,
  Plus,
  X,
  Lightbulb,
  CheckCircle,
  AlertCircle,
  FileText,
  Brain,
  RefreshCw,
} from "lucide-react"
import { useRouter } from "next/navigation"

interface AITip {
  section: string
  tip: string
  type: "suggestion" | "improvement" | "recommendation"
}

function ResumeBuilderPage() {
  const router = useRouter()
  const [activeSection, setActiveSection] = useState("personal")
  const [skills, setSkills] = useState(["JavaScript", "React", "Node.js"])
  const [newSkill, setNewSkill] = useState("")
  const [experiences, setExperiences] = useState([
    {
      id: "1",
      title: "Frontend Developer Intern",
      company: "TechStart",
      duration: "Jun 2024 - Aug 2024",
      description: "Developed responsive web applications using React and TypeScript",
    },
  ])

  const [aiTips] = useState<AITip[]>([
    {
      section: "summary",
      tip: "Your summary should be 2-3 sentences highlighting your key skills and career goals.",
      type: "suggestion",
    },
    {
      section: "experience",
      tip: "Use action verbs like 'developed', 'implemented', 'designed' to start your bullet points.",
      type: "improvement",
    },
    {
      section: "skills",
      tip: "Add 'React' and 'TypeScript' to match more frontend internship requirements.",
      type: "recommendation",
    },
    {
      section: "education",
      tip: "Include relevant coursework and projects that demonstrate your technical skills.",
      type: "suggestion",
    },
    {
      section: "formatting",
      tip: "Keep your resume to one page and use consistent formatting throughout.",
      type: "improvement",
    },
  ])
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    location: "",
    linkedin: "",
    github: "",
    summary: "",
    degree: "",
    field: "",
    college: "",
    graduation: "",
    gpa: "",
  })

  const analyzeResume = async () => {
    setIsAnalyzing(true)
    // Simulate analysis delay
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsAnalyzing(false)
  }

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove))
  }

  const addExperience = () => {
    const newExp = {
      id: Date.now().toString(),
      title: "",
      company: "",
      duration: "",
      description: "",
    }
    setExperiences([...experiences, newExp])
  }

  const updateFormData = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold flex items-center space-x-2">
                  <FileText className="w-8 h-8 text-primary" />
                  <span>Resume Builder</span>
                </h1>
                <p className="text-muted-foreground mt-1">Create a professional resume with AI-powered tips</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={analyzeResume} disabled={isAnalyzing}>
                <RefreshCw className={`w-4 h-4 mr-2 ${isAnalyzing ? "animate-spin" : ""}`} />
                {isAnalyzing ? "Analyzing..." : "AI Analysis"}
              </Button>
              <Button variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Resume Builder Form */}
            <div className="lg:col-span-2">
              <Tabs value={activeSection} onValueChange={setActiveSection}>
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="summary">Summary</TabsTrigger>
                  <TabsTrigger value="experience">Experience</TabsTrigger>
                  <TabsTrigger value="education">Education</TabsTrigger>
                  <TabsTrigger value="skills">Skills</TabsTrigger>
                </TabsList>

                <TabsContent value="personal" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Personal Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="firstName">First Name</Label>
                          <Input
                            id="firstName"
                            placeholder="John"
                            value={formData.firstName}
                            onChange={(e) => updateFormData("firstName", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input
                            id="lastName"
                            placeholder="Doe"
                            value={formData.lastName}
                            onChange={(e) => updateFormData("lastName", e.target.value)}
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="john@example.com"
                          value={formData.email}
                          onChange={(e) => updateFormData("email", e.target.value)}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            placeholder="+91 9876543210"
                            value={formData.phone}
                            onChange={(e) => updateFormData("phone", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="location">Location</Label>
                          <Input
                            id="location"
                            placeholder="Bangalore, India"
                            value={formData.location}
                            onChange={(e) => updateFormData("location", e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="linkedin">LinkedIn</Label>
                          <Input
                            id="linkedin"
                            placeholder="linkedin.com/in/johndoe"
                            value={formData.linkedin}
                            onChange={(e) => updateFormData("linkedin", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="github">GitHub</Label>
                          <Input
                            id="github"
                            placeholder="github.com/johndoe"
                            value={formData.github}
                            onChange={(e) => updateFormData("github", e.target.value)}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="summary" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Professional Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div>
                        <Label htmlFor="summary">Summary</Label>
                        <Textarea
                          id="summary"
                          placeholder="Write a brief summary of your background, skills, and career objectives..."
                          rows={6}
                          className="mt-1"
                          value={formData.summary}
                          onChange={(e) => updateFormData("summary", e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Keep it concise - 2-3 sentences highlighting your key strengths
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="experience" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Work Experience</CardTitle>
                        <Button onClick={addExperience} size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Experience
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {experiences.map((exp, index) => (
                        <div key={exp.id} className="p-4 border rounded-lg space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">Experience {index + 1}</h4>
                            {experiences.length > 1 && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setExperiences(experiences.filter((e) => e.id !== exp.id))}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Job Title</Label>
                              <Input
                                placeholder="Frontend Developer Intern"
                                value={exp.title}
                                onChange={(e) => {
                                  const updatedExperiences = experiences.map((e) =>
                                    e.id === exp.id ? { ...e, title: e.target.value } : e,
                                  )
                                  setExperiences(updatedExperiences)
                                }}
                              />
                            </div>
                            <div>
                              <Label>Company</Label>
                              <Input
                                placeholder="TechCorp"
                                value={exp.company}
                                onChange={(e) => {
                                  const updatedExperiences = experiences.map((e) =>
                                    e.id === exp.id ? { ...e, company: e.target.value } : e,
                                  )
                                  setExperiences(updatedExperiences)
                                }}
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Duration</Label>
                              <Input
                                placeholder="Jun 2024 - Aug 2024"
                                value={exp.duration}
                                onChange={(e) => {
                                  const updatedExperiences = experiences.map((e) =>
                                    e.id === exp.id ? { ...e, duration: e.target.value } : e,
                                  )
                                  setExperiences(updatedExperiences)
                                }}
                              />
                            </div>
                            <div>
                              <Label>Location</Label>
                              <Input
                                placeholder="Bangalore, India"
                                value={exp.location}
                                onChange={(e) => {
                                  const updatedExperiences = experiences.map((e) =>
                                    e.id === exp.id ? { ...e, location: e.target.value } : e,
                                  )
                                  setExperiences(updatedExperiences)
                                }}
                              />
                            </div>
                          </div>
                          <div>
                            <Label>Description</Label>
                            <Textarea
                              placeholder="Describe your responsibilities and achievements..."
                              rows={3}
                              value={exp.description}
                              onChange={(e) => {
                                const updatedExperiences = experiences.map((e) =>
                                  e.id === exp.id ? { ...e, description: e.target.value } : e,
                                )
                                setExperiences(updatedExperiences)
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="education" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Education</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="degree">Degree</Label>
                          <Input
                            id="degree"
                            placeholder="Bachelor of Technology"
                            value={formData.degree}
                            onChange={(e) => updateFormData("degree", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="field">Field of Study</Label>
                          <Input
                            id="field"
                            placeholder="Computer Science"
                            value={formData.field}
                            onChange={(e) => updateFormData("field", e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="college">College/University</Label>
                          <Input
                            id="college"
                            placeholder="IIT Delhi"
                            value={formData.college}
                            onChange={(e) => updateFormData("college", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="graduation">Graduation Year</Label>
                          <Select
                            value={formData.graduation}
                            onValueChange={(value) => updateFormData("graduation", value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select year" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="2025">2025</SelectItem>
                              <SelectItem value="2026">2026</SelectItem>
                              <SelectItem value="2027">2027</SelectItem>
                              <SelectItem value="2028">2028</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="gpa">GPA (Optional)</Label>
                          <Input
                            id="gpa"
                            placeholder="8.5/10"
                            value={formData.gpa}
                            onChange={(e) => updateFormData("gpa", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="eduLocation">Location</Label>
                          <Input id="eduLocation" placeholder="Delhi, India" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="skills" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Skills</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label>Add Skills</Label>
                        <div className="flex space-x-2 mt-1">
                          <Input
                            placeholder="Enter a skill"
                            value={newSkill}
                            onChange={(e) => setNewSkill(e.target.value)}
                            onKeyPress={(e) => e.key === "Enter" && addSkill()}
                          />
                          <Button onClick={addSkill}>Add</Button>
                        </div>
                      </div>
                      <div>
                        <Label>Your Skills</Label>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {skills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="flex items-center space-x-1">
                              <span>{skill}</span>
                              <button onClick={() => removeSkill(skill)} className="ml-1 hover:text-destructive">
                                <X className="w-3 h-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* AI Tips Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Brain className="w-5 h-5 text-primary" />
                      <span>AI Tips</span>
                    </div>
                    {isAnalyzing && <RefreshCw className="w-4 h-4 text-primary animate-spin" />}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {aiTips.map((tip, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg border ${
                        tip.type === "recommendation"
                          ? "bg-blue-50 border-blue-200"
                          : tip.type === "improvement"
                            ? "bg-orange-50 border-orange-200"
                            : "bg-green-50 border-green-200"
                      }`}
                    >
                      <div className="flex items-start space-x-2">
                        {tip.type === "recommendation" ? (
                          <Lightbulb className="w-4 h-4 text-blue-600 mt-0.5" />
                        ) : tip.type === "improvement" ? (
                          <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5" />
                        ) : (
                          <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                        )}
                        <div>
                          <p className="text-sm font-medium capitalize">{tip.section}</p>
                          <p className="text-xs text-muted-foreground mt-1">{tip.tip}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resume Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">85%</div>
                    <p className="text-sm text-muted-foreground mb-4">Your resume is looking great!</p>
                    <div className="space-y-2 text-left">
                      <div className="flex items-center justify-between text-sm">
                        <span>Completeness</span>
                        <span className="font-medium">90%</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>ATS Compatibility</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>AI Optimization</span>
                        <span className="font-medium">88%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview Resume
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <FileText className="w-4 h-4 mr-2" />
                    Save Template
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}

export default ResumeBuilderPage
