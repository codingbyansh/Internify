"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Bell, BellRing, Check, X, Brain, Building2, Calendar, Settings, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

// Mock notifications data
const mockNotifications = [
  {
    id: "1",
    type: "match",
    title: "New AI Match Found!",
    message: "We found a 95% match for Frontend Developer Intern at TechCorp",
    timestamp: "2 minutes ago",
    read: false,
    icon: Brain,
    color: "text-primary",
    actionUrl: "/internship/1",
  },
  {
    id: "2",
    type: "application",
    title: "Application Status Update",
    message: "Your application for Backend Developer Intern has been shortlisted",
    timestamp: "1 hour ago",
    read: false,
    icon: Building2,
    color: "text-green-600",
    actionUrl: "/dashboard/student/applications",
  },
  {
    id: "3",
    type: "interview",
    title: "Interview Scheduled",
    message: "Interview scheduled for Data Science Intern at DataFlow - Tomorrow 2:00 PM",
    timestamp: "3 hours ago",
    read: true,
    icon: Calendar,
    color: "text-blue-600",
    actionUrl: "/dashboard/student/applications",
  },
  {
    id: "4",
    type: "reminder",
    title: "Application Deadline Reminder",
    message: "Don't forget! UI/UX Design Intern application deadline is in 2 days",
    timestamp: "1 day ago",
    read: true,
    icon: Bell,
    color: "text-orange-600",
    actionUrl: "/internship/3",
  },
  {
    id: "5",
    type: "system",
    title: "Profile Completion",
    message: "Complete your profile to get better AI recommendations",
    timestamp: "2 days ago",
    read: true,
    icon: Settings,
    color: "text-purple-600",
    actionUrl: "/dashboard/student/profile",
  },
]

function NotificationsPage() {
  const router = useRouter()
  const [notifications, setNotifications] = useState(mockNotifications)
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [pushNotifications, setPushNotifications] = useState(true)
  const [aiRecommendations, setAiRecommendations] = useState(true)
  const [applicationUpdates, setApplicationUpdates] = useState(true)

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notification) => ({ ...notification, read: true })))
  }

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold flex items-center space-x-2">
                  <Bell className="w-8 h-8 text-primary" />
                  <span>Notifications</span>
                  {unreadCount > 0 && <Badge className="bg-red-500 text-white">{unreadCount}</Badge>}
                </h1>
                <p className="text-muted-foreground mt-1">Stay updated with your internship journey</p>
              </div>
            </div>
            {unreadCount > 0 && (
              <Button onClick={markAllAsRead} variant="outline">
                <Check className="w-4 h-4 mr-2" />
                Mark All Read
              </Button>
            )}
          </div>

          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Notifications</TabsTrigger>
              <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              {notifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`transition-all hover:shadow-md ${
                    !notification.read ? "border-primary/20 bg-primary/5" : ""
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center ${notification.color}`}
                      >
                        <notification.icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold mb-1">{notification.title}</h3>
                            <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                            <p className="text-xs text-muted-foreground">{notification.timestamp}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            {!notification.read && <div className="w-2 h-2 bg-primary rounded-full"></div>}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => markAsRead(notification.id)}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteNotification(notification.id)}
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        {notification.actionUrl && (
                          <Link href={notification.actionUrl}>
                            <Button size="sm" variant="outline" className="mt-3 bg-transparent">
                              View Details
                            </Button>
                          </Link>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="unread" className="space-y-4">
              {notifications
                .filter((n) => !n.read)
                .map((notification) => (
                  <Card key={notification.id} className="border-primary/20 bg-primary/5">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div
                          className={`w-10 h-10 rounded-full bg-muted flex items-center justify-center ${notification.color}`}
                        >
                          <notification.icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-semibold mb-1">{notification.title}</h3>
                              <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                              <p className="text-xs text-muted-foreground">{notification.timestamp}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-primary rounded-full"></div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => markAsRead(notification.id)}
                                className="text-muted-foreground hover:text-foreground"
                              >
                                <Check className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteNotification(notification.id)}
                                className="text-muted-foreground hover:text-foreground"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                          {notification.actionUrl && (
                            <Link href={notification.actionUrl}>
                              <Button size="sm" variant="outline" className="mt-3 bg-transparent">
                                View Details
                              </Button>
                            </Link>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              {notifications.filter((n) => !n.read).length === 0 && (
                <Card>
                  <CardContent className="p-12 text-center">
                    <BellRing className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">All caught up!</h3>
                    <p className="text-muted-foreground">You have no unread notifications.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="email-notifications" className="text-base font-medium">
                        Email Notifications
                      </Label>
                      <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                    </div>
                    <Switch
                      id="email-notifications"
                      checked={emailNotifications}
                      onCheckedChange={setEmailNotifications}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="push-notifications" className="text-base font-medium">
                        Push Notifications
                      </Label>
                      <p className="text-sm text-muted-foreground">Receive browser push notifications</p>
                    </div>
                    <Switch
                      id="push-notifications"
                      checked={pushNotifications}
                      onCheckedChange={setPushNotifications}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="ai-recommendations" className="text-base font-medium">
                        AI Recommendations
                      </Label>
                      <p className="text-sm text-muted-foreground">Get notified about new AI-matched internships</p>
                    </div>
                    <Switch
                      id="ai-recommendations"
                      checked={aiRecommendations}
                      onCheckedChange={setAiRecommendations}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="application-updates" className="text-base font-medium">
                        Application Updates
                      </Label>
                      <p className="text-sm text-muted-foreground">Status updates for your applications</p>
                    </div>
                    <Switch
                      id="application-updates"
                      checked={applicationUpdates}
                      onCheckedChange={setApplicationUpdates}
                    />
                  </div>

                  <Button className="w-full">Save Preferences</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}

export default NotificationsPage
