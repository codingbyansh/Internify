import type React from "react"

export default function StudentDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
