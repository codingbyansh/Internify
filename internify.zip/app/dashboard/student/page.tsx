"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  Brain,
  Search,
  MapPin,
  DollarSign,
  Clock,
  Building2,
  Heart,
  Send,
  User,
  BookmarkPlus,
  Bell,
  Settings,
  LogOut,
  TrendingUp,
  Calendar,
  CheckCircle,
  Star,
  Filter,
  FileText,
  RefreshCw,
} from "lucide-react"
import { authService } from "@/lib/auth"
import Link from "next/link"

// Mock data for internships
const mockInternships = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "TechCorp",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
    location: "Bangalore, India",
    stipend: "₹25,000/month",
    duration: "3 months",
    type: "Remote",
    skills: ["React", "JavaScript", "CSS"],
    aiMatch: 95,
    description: "Work on cutting-edge web applications using React and modern JavaScript frameworks.",
    posted: "2 days ago",
    applicants: 45,
  },
  {
    id: "2",
    title: "Data Science Intern",
    company: "DataFlow",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=dataflow",
    location: "Mumbai, India",
    stipend: "₹30,000/month",
    duration: "6 months",
    type: "Hybrid",
    skills: ["Python", "Machine Learning", "SQL"],
    aiMatch: 88,
    description: "Analyze large datasets and build predictive models for business insights.",
    posted: "1 day ago",
    applicants: 32,
  },
  {
    id: "3",
    title: "UI/UX Design Intern",
    company: "DesignStudio",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=designstudio",
    location: "Delhi, India",
    stipend: "₹20,000/month",
    duration: "4 months",
    type: "On-site",
    skills: ["Figma", "Adobe XD", "User Research"],
    aiMatch: 82,
    description: "Create beautiful and intuitive user interfaces for mobile and web applications.",
    posted: "3 days ago",
    applicants: 28,
  },
  {
    id: "4",
    title: "Backend Developer Intern",
    company: "CloudTech",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=cloudtech",
    location: "Hyderabad, India",
    stipend: "₹28,000/month",
    duration: "5 months",
    type: "Remote",
    skills: ["Node.js", "MongoDB", "AWS"],
    aiMatch: 91,
    description: "Build scalable backend systems and APIs for cloud-based applications.",
    posted: "1 week ago",
    applicants: 67,
  },
]

function StudentDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [locationFilter, setLocationFilter] = useState("All Locations")
  const [stipendFilter, setStipendFilter] = useState("")
  const [durationFilter, setDurationFilter] = useState("")
  const [typeFilter, setTypeFilter] = useState("All Types")
  const [savedInternships, setSavedInternships] = useState<string[]>([])
  const [isRefreshing, setIsRefreshing] = useState(false)

  const user = authService.getCurrentUser()

  const refreshRecommendations = async () => {
    setIsRefreshing(true)
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsRefreshing(false)
  }

  const handleSaveInternship = (internshipId: string) => {
    setSavedInternships((prev) =>
      prev.includes(internshipId) ? prev.filter((id) => id !== internshipId) : [...prev, internshipId],
    )
  }

  const getFilteredInternships = () => {
    return mockInternships
      .sort((a, b) => b.aiMatch - a.aiMatch)
      .filter((internship) => {
        const matchesSearch =
          internship.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          internship.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
          internship.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))

        const matchesLocation = locationFilter === "All Locations" || internship.location.includes(locationFilter)
        const matchesType = typeFilter === "All Types" || internship.type === typeFilter

        return matchesSearch && matchesLocation && matchesType
      })
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-card border-r min-h-screen p-4">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">Internify</span>
            </div>

            <nav className="space-y-2">
              <Link
                href="/dashboard/student"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg bg-primary/10 text-primary"
              >
                <TrendingUp className="w-4 h-4" />
                <span>Dashboard</span>
              </Link>
              <Link
                href="/dashboard/student/profile"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </Link>
              <Link
                href="/dashboard/student/recommended"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Brain className="w-4 h-4" />
                <span>Recommended</span>
              </Link>
              <Link
                href="/dashboard/student/applications"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Send className="w-4 h-4" />
                <span>Applications</span>
              </Link>
              <Link
                href="/dashboard/student/saved"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Heart className="w-4 h-4" />
                <span>Saved Internships</span>
              </Link>
              <Link
                href="/dashboard/student/notifications"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Bell className="w-4 h-4" />
                <span>Notifications</span>
              </Link>
              <Link
                href="/dashboard/student/resume-builder"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <FileText className="w-4 h-4" />
                <span>Resume Builder</span>
              </Link>
            </nav>

            <Separator className="my-6" />

            <nav className="space-y-2">
              <Link
                href="/dashboard/student/settings"
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </Link>
              <button
                onClick={() => {
                  authService.logout()
                  window.location.href = "/"
                }}
                className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted w-full text-left"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-balance">Welcome back, {user?.firstName || "Student"}! 👋</h1>
                <p className="text-muted-foreground mt-1">
                  Discover your perfect internship with AI-powered recommendations
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <ThemeToggle />
                <Button variant="outline" size="sm" onClick={refreshRecommendations} disabled={isRefreshing}>
                  <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                  {isRefreshing ? "Refreshing..." : "Refresh"}
                </Button>
                <Button variant="outline" size="sm">
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </Button>
                <Avatar>
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                  <AvatarFallback>
                    {user?.firstName?.[0]}
                    {user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>

            {/* Progress Tracker */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Applications Submitted</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">12</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <Progress value={60} className="flex-1" />
                    <span className="text-sm text-muted-foreground">60%</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Interviews Scheduled</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <Calendar className="w-4 h-4 text-accent" />
                    <span className="text-sm text-muted-foreground">Next: Tomorrow 2 PM</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Offers Received</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1</div>
                  <div className="flex items-center space-x-2 mt-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-muted-foreground">Pending response</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Search and Filters */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Search className="w-5 h-5" />
                  <span>Find Your Perfect Internship</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search by role, company, or skills..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Select value={locationFilter} onValueChange={setLocationFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Locations">All Locations</SelectItem>
                        <SelectItem value="Bangalore">Bangalore</SelectItem>
                        <SelectItem value="Mumbai">Mumbai</SelectItem>
                        <SelectItem value="Delhi">Delhi</SelectItem>
                        <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={typeFilter} onValueChange={setTypeFilter}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Types">All Types</SelectItem>
                        <SelectItem value="Remote">Remote</SelectItem>
                        <SelectItem value="On-site">On-site</SelectItem>
                        <SelectItem value="Hybrid">Hybrid</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button variant="outline" size="icon">
                      <Filter className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold flex items-center space-x-2">
                  <Brain className="w-6 h-6 text-primary" />
                  <span>AI Recommendations</span>
                </h2>
                <Badge className="bg-primary/10 text-primary border-primary/20">
                  {getFilteredInternships().length} matches found
                </Badge>
              </div>

              <div className="grid gap-6">
                {getFilteredInternships().map((internship) => (
                  <Card key={internship.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex space-x-4 flex-1">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={internship.logo || "/placeholder.svg"} />
                            <AvatarFallback>{internship.company[0]}</AvatarFallback>
                          </Avatar>

                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold">{internship.title}</h3>
                              <Badge
                                className={`${
                                  internship.aiMatch >= 90
                                    ? "bg-green-100 text-green-800 border-green-200"
                                    : internship.aiMatch >= 80
                                      ? "bg-blue-100 text-blue-800 border-blue-200"
                                      : "bg-yellow-100 text-yellow-800 border-yellow-200"
                                }`}
                              >
                                <Star className="w-3 h-3 mr-1" />
                                {internship.aiMatch}% match
                              </Badge>
                            </div>

                            <p className="text-muted-foreground mb-3">{internship.company}</p>

                            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{internship.location}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <DollarSign className="w-4 h-4" />
                                <span>{internship.stipend}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>{internship.duration}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Building2 className="w-4 h-4" />
                                <span>{internship.type}</span>
                              </div>
                            </div>

                            <p className="text-sm text-muted-foreground mb-3">{internship.description}</p>

                            <div className="flex flex-wrap gap-2 mb-3">
                              {internship.skills.map((skill) => (
                                <Badge key={skill} variant="secondary" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>

                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>Posted {internship.posted}</span>
                              <span>{internship.applicants} applicants</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-4">
                          <Link href={`/internship/${internship.id}`}>
                            <Button size="sm" className="w-full">
                              Apply Now
                            </Button>
                          </Link>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSaveInternship(internship.id)}
                            className={`w-full ${
                              savedInternships.includes(internship.id)
                                ? "bg-accent/10 text-accent border-accent/20"
                                : ""
                            }`}
                          >
                            {savedInternships.includes(internship.id) ? (
                              <Heart className="w-4 h-4 mr-1 fill-current" />
                            ) : (
                              <BookmarkPlus className="w-4 h-4 mr-1" />
                            )}
                            {savedInternships.includes(internship.id) ? "Saved" : "Save"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}

export default StudentDashboard
