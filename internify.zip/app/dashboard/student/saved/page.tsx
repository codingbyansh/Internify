"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Heart, MapPin, DollarSign, Clock, Building2, Star, Send, X } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

const mockSavedInternships = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    company: "TechCorp",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
    location: "Bangalore, India",
    stipend: "₹25,000/month",
    duration: "3 months",
    type: "Remote",
    skills: ["React", "JavaScript", "CSS"],
    aiMatch: 95,
    description: "Work on cutting-edge web applications using React and modern JavaScript frameworks.",
    posted: "2 days ago",
    applicants: 45,
    savedDate: "2024-01-20",
  },
  {
    id: "2",
    title: "Data Science Intern",
    company: "DataFlow",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=dataflow",
    location: "Mumbai, India",
    stipend: "₹30,000/month",
    duration: "6 months",
    type: "Hybrid",
    skills: ["Python", "Machine Learning", "SQL"],
    aiMatch: 88,
    description: "Analyze large datasets and build predictive models for business insights.",
    posted: "1 day ago",
    applicants: 32,
    savedDate: "2024-01-19",
  },
  {
    id: "3",
    title: "UI/UX Design Intern",
    company: "DesignStudio",
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=designstudio",
    location: "Delhi, India",
    stipend: "₹20,000/month",
    duration: "4 months",
    type: "On-site",
    skills: ["Figma", "Adobe XD", "User Research"],
    aiMatch: 82,
    description: "Create beautiful and intuitive user interfaces for mobile and web applications.",
    posted: "3 days ago",
    applicants: 28,
    savedDate: "2024-01-18",
  },
]

function SavedInternshipsPage() {
  const router = useRouter()
  const [savedInternships, setSavedInternships] = useState(mockSavedInternships)

  const removeSaved = (internshipId: string) => {
    setSavedInternships((prev) => prev.filter((internship) => internship.id !== internshipId))
  }

  return (
    <AuthGuard requiredRole="student">
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => router.back()} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </Button>
              <div>
                <h1 className="text-3xl font-bold flex items-center space-x-2">
                  <Heart className="w-8 h-8 text-primary" />
                  <span>Saved Internships</span>
                </h1>
                <p className="text-muted-foreground mt-1">Your bookmarked internship opportunities</p>
              </div>
            </div>
            <Badge className="bg-primary/10 text-primary border-primary/20">{savedInternships.length} saved</Badge>
          </div>

          {savedInternships.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No saved internships yet</h3>
                <p className="text-muted-foreground mb-6">
                  Start exploring internships and save the ones you're interested in!
                </p>
                <Link href="/dashboard/student">
                  <Button>Explore Internships</Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6">
              {savedInternships.map((internship) => (
                <Card key={internship.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex space-x-4 flex-1">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={internship.logo || "/placeholder.svg"} />
                          <AvatarFallback>{internship.company[0]}</AvatarFallback>
                        </Avatar>

                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-xl font-semibold">{internship.title}</h3>
                            <Badge
                              className={`${
                                internship.aiMatch >= 90
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : internship.aiMatch >= 80
                                    ? "bg-blue-100 text-blue-800 border-blue-200"
                                    : "bg-yellow-100 text-yellow-800 border-yellow-200"
                              }`}
                            >
                              <Star className="w-3 h-3 mr-1" />
                              {internship.aiMatch}% match
                            </Badge>
                          </div>

                          <p className="text-muted-foreground mb-3">{internship.company}</p>

                          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                            <div className="flex items-center space-x-1">
                              <MapPin className="w-4 h-4" />
                              <span>{internship.location}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <DollarSign className="w-4 h-4" />
                              <span>{internship.stipend}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>{internship.duration}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Building2 className="w-4 h-4" />
                              <span>{internship.type}</span>
                            </div>
                          </div>

                          <p className="text-sm text-muted-foreground mb-3">{internship.description}</p>

                          <div className="flex flex-wrap gap-2 mb-3">
                            {internship.skills.map((skill) => (
                              <Badge key={skill} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Posted {internship.posted}</span>
                            <span>Saved on {new Date(internship.savedDate).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col space-y-2 ml-4">
                        <Link href={`/internship/${internship.id}`}>
                          <Button size="sm" className="w-full">
                            <Send className="w-4 h-4 mr-1" />
                            Apply Now
                          </Button>
                        </Link>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeSaved(internship.id)}
                          className="w-full text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4 mr-1" />
                          Remove
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </AuthGuard>
  )
}

export default SavedInternshipsPage
