import type React from "react"

export default function RecruiterDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
