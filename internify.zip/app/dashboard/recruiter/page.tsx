"use client"

import type React from "react"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Brain,
  Plus,
  Users,
  TrendingUp,
  Building2,
  MapPin,
  DollarSign,
  Clock,
  Eye,
  CheckCircle,
  X,
  Star,
  Download,
  Mail,
  Phone,
  Calendar,
  BarChart3,
  Settings,
  LogOut,
  Search,
} from "lucide-react"
import { authService } from "@/lib/auth"
import Link from "next/link"

// Mock data for recruiter dashboard
const mockInternships = [
  {
    id: "1",
    title: "Frontend Developer Intern",
    location: "Bangalore, India",
    stipend: "₹25,000/month",
    duration: "3 months",
    type: "Remote",
    status: "Active",
    applicants: 45,
    shortlisted: 8,
    hired: 0,
    posted: "2 days ago",
    deadline: "2025-01-15",
  },
  {
    id: "2",
    title: "Backend Developer Intern",
    location: "Mumbai, India",
    stipend: "₹28,000/month",
    duration: "5 months",
    type: "Hybrid",
    status: "Active",
    applicants: 32,
    shortlisted: 5,
    hired: 1,
    posted: "1 week ago",
    deadline: "2025-01-20",
  },
  {
    id: "3",
    title: "Data Science Intern",
    location: "Delhi, India",
    stipend: "₹30,000/month",
    duration: "6 months",
    type: "On-site",
    status: "Closed",
    applicants: 67,
    shortlisted: 12,
    hired: 2,
    posted: "2 weeks ago",
    deadline: "2024-12-30",
  },
]

const mockApplicants = [
  {
    id: "1",
    name: "Ansh Kumar",
    email: "ansh@example.com",
    phone: "+91 9876543210",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ansh",
    skills: ["React", "JavaScript", "CSS", "Node.js"],
    experience: "2 years",
    education: "B.Tech Computer Science",
    college: "IIT Delhi",
    aiMatch: 95,
    status: "Applied",
    appliedDate: "2025-01-10",
    internshipId: "1",
    internshipTitle: "Frontend Developer Intern",
    resumeUrl: "#",
    coverLetter: "I am passionate about frontend development and have worked on several React projects...",
  },
  {
    id: "2",
    name: "Priya Sharma",
    email: "priya@example.com",
    phone: "+91 9876543211",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=priya",
    skills: ["Python", "Machine Learning", "SQL", "TensorFlow"],
    experience: "1.5 years",
    education: "M.Tech Data Science",
    college: "IIIT Bangalore",
    aiMatch: 92,
    status: "Shortlisted",
    appliedDate: "2025-01-08",
    internshipId: "2",
    internshipTitle: "Backend Developer Intern",
    resumeUrl: "#",
    coverLetter: "I have strong experience in backend development and database management...",
  },
  {
    id: "3",
    name: "Rahul Verma",
    email: "rahul@example.com",
    phone: "+91 9876543212",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=rahul",
    skills: ["Java", "Spring Boot", "MySQL", "AWS"],
    experience: "1 year",
    education: "B.Tech Information Technology",
    college: "NIT Trichy",
    aiMatch: 88,
    status: "Interviewed",
    appliedDate: "2025-01-05",
    internshipId: "1",
    internshipTitle: "Frontend Developer Intern",
    resumeUrl: "#",
    coverLetter: "I am excited about the opportunity to work with your team and contribute to innovative projects...",
  },
]

function RecruiterDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isPostingInternship, setIsPostingInternship] = useState(false)
  const [selectedApplicant, setSelectedApplicant] = useState<(typeof mockApplicants)[0] | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")

  const user = authService.getCurrentUser()

  const handlePostInternship = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsPostingInternship(true)
    // Simulate API call
    setTimeout(() => {
      setIsPostingInternship(false)
      // Close dialog and refresh data
    }, 2000)
  }

  const handleShortlist = (applicantId: string) => {
    // Update applicant status to shortlisted
    console.log("Shortlisting applicant:", applicantId)
  }

  const handleReject = (applicantId: string) => {
    // Update applicant status to rejected
    console.log("Rejecting applicant:", applicantId)
  }

  const filteredApplicants = mockApplicants.filter((applicant) => {
    const matchesSearch =
      applicant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      applicant.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      applicant.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesStatus = statusFilter === "All" || applicant.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const totalApplicants = mockInternships.reduce((sum, internship) => sum + internship.applicants, 0)
  const totalShortlisted = mockInternships.reduce((sum, internship) => sum + internship.shortlisted, 0)
  const totalHired = mockInternships.reduce((sum, internship) => sum + internship.hired, 0)

  return (
    <AuthGuard requiredRole="recruiter">
      <div className="min-h-screen bg-background">
        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-card border-r min-h-screen p-4">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">Internify</span>
            </div>

            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab("overview")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "overview"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <TrendingUp className="w-4 h-4" />
                <span>Overview</span>
              </button>
              <button
                onClick={() => setActiveTab("internships")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "internships"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span>My Internships</span>
              </button>
              <button
                onClick={() => setActiveTab("applicants")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "applicants"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Applicants</span>
              </button>
              <button
                onClick={() => setActiveTab("analytics")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "analytics"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>Analytics</span>
              </button>
            </nav>

            <div className="mt-8 pt-8 border-t">
              <nav className="space-y-2">
                <Link
                  href="/dashboard/recruiter/settings"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </Link>
                <button
                  onClick={() => {
                    authService.logout()
                    window.location.href = "/"
                  }}
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted w-full text-left"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-balance">Welcome back, {user?.firstName || "Recruiter"}! 👋</h1>
                <p className="text-muted-foreground mt-1">Manage your internships and find the best talent</p>
              </div>
              <div className="flex items-center space-x-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Post New Internship
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Post New Internship</DialogTitle>
                      <DialogDescription>Create a new internship opportunity for students</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handlePostInternship} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="title">Job Title *</Label>
                          <Input id="title" placeholder="e.g. Frontend Developer Intern" required />
                        </div>
                        <div>
                          <Label htmlFor="department">Department</Label>
                          <Input id="department" placeholder="e.g. Engineering" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="description">Job Description *</Label>
                        <Textarea
                          id="description"
                          placeholder="Describe the role, responsibilities, and what the intern will learn..."
                          rows={4}
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="location">Location *</Label>
                          <Input id="location" placeholder="e.g. Bangalore, India" required />
                        </div>
                        <div>
                          <Label htmlFor="type">Work Type *</Label>
                          <Select required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select work type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="remote">Remote</SelectItem>
                              <SelectItem value="onsite">On-site</SelectItem>
                              <SelectItem value="hybrid">Hybrid</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="stipend">Stipend *</Label>
                          <Input id="stipend" placeholder="e.g. ₹25,000/month" required />
                        </div>
                        <div>
                          <Label htmlFor="duration">Duration *</Label>
                          <Input id="duration" placeholder="e.g. 3 months" required />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="skills">Required Skills *</Label>
                        <Input id="skills" placeholder="e.g. React, JavaScript, CSS (comma separated)" required />
                      </div>

                      <div>
                        <Label htmlFor="requirements">Requirements</Label>
                        <Textarea
                          id="requirements"
                          placeholder="List the qualifications and requirements for this role..."
                          rows={3}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="startDate">Start Date</Label>
                          <Input id="startDate" type="date" />
                        </div>
                        <div>
                          <Label htmlFor="deadline">Application Deadline</Label>
                          <Input id="deadline" type="date" />
                        </div>
                      </div>

                      <div className="flex justify-end space-x-3 pt-4">
                        <DialogTrigger asChild>
                          <Button variant="outline" type="button">
                            Cancel
                          </Button>
                        </DialogTrigger>
                        <Button type="submit" disabled={isPostingInternship}>
                          {isPostingInternship ? "Posting..." : "Post Internship"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
                <Avatar>
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                  <AvatarFallback>
                    {user?.firstName?.[0]}
                    {user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>

            {/* Content based on active tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid md:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Active Internships</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {mockInternships.filter((i) => i.status === "Active").length}
                      </div>
                      <p className="text-xs text-muted-foreground">Currently hiring</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Total Applicants</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalApplicants}</div>
                      <p className="text-xs text-muted-foreground">Across all internships</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Shortlisted</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalShortlisted}</div>
                      <p className="text-xs text-muted-foreground">Ready for interviews</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Hired</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalHired}</div>
                      <p className="text-xs text-muted-foreground">Successfully placed</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm">New application for Frontend Developer Intern</span>
                        <span className="text-xs text-muted-foreground ml-auto">2 hours ago</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">Candidate shortlisted for Backend Developer Intern</span>
                        <span className="text-xs text-muted-foreground ml-auto">5 hours ago</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <span className="text-sm">Interview scheduled for Data Science Intern</span>
                        <span className="text-xs text-muted-foreground ml-auto">1 day ago</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === "internships" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">My Internships</h2>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Post New Internship
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Post New Internship</DialogTitle>
                        <DialogDescription>Create a new internship opportunity for students</DialogDescription>
                      </DialogHeader>
                      {/* Same form as above */}
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="grid gap-6">
                  {mockInternships.map((internship) => (
                    <Card key={internship.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold">{internship.title}</h3>
                              <Badge
                                className={
                                  internship.status === "Active"
                                    ? "bg-green-100 text-green-800 border-green-200"
                                    : "bg-gray-100 text-gray-800 border-gray-200"
                                }
                              >
                                {internship.status}
                              </Badge>
                            </div>

                            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{internship.location}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <DollarSign className="w-4 h-4" />
                                <span>{internship.stipend}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>{internship.duration}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Building2 className="w-4 h-4" />
                                <span>{internship.type}</span>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <span className="text-muted-foreground">Applicants:</span>
                                <span className="font-medium ml-1">{internship.applicants}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Shortlisted:</span>
                                <span className="font-medium ml-1">{internship.shortlisted}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Hired:</span>
                                <span className="font-medium ml-1">{internship.hired}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col space-y-2 ml-4">
                            <Button size="sm" variant="outline">
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </Button>
                            <Button size="sm" variant="outline">
                              <Users className="w-4 h-4 mr-2" />
                              View Applicants
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "applicants" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Applicants</h2>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Search className="w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search applicants..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-64"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All Status</SelectItem>
                        <SelectItem value="Applied">Applied</SelectItem>
                        <SelectItem value="Shortlisted">Shortlisted</SelectItem>
                        <SelectItem value="Interviewed">Interviewed</SelectItem>
                        <SelectItem value="Hired">Hired</SelectItem>
                        <SelectItem value="Rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-4">
                  {filteredApplicants.map((applicant) => (
                    <Card key={applicant.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex space-x-4 flex-1">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={applicant.avatar || "/placeholder.svg"} />
                              <AvatarFallback>
                                {applicant.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>

                            <div className="flex-1">
                              <div className="flex items-center space-x-3 mb-2">
                                <h3 className="text-lg font-semibold">{applicant.name}</h3>
                                <Badge
                                  className={`${
                                    applicant.aiMatch >= 90
                                      ? "bg-green-100 text-green-800 border-green-200"
                                      : applicant.aiMatch >= 80
                                        ? "bg-blue-100 text-blue-800 border-blue-200"
                                        : "bg-yellow-100 text-yellow-800 border-yellow-200"
                                  }`}
                                >
                                  <Star className="w-3 h-3 mr-1" />
                                  {applicant.aiMatch}% match
                                </Badge>
                                <Badge
                                  className={
                                    applicant.status === "Shortlisted"
                                      ? "bg-blue-100 text-blue-800 border-blue-200"
                                      : applicant.status === "Interviewed"
                                        ? "bg-purple-100 text-purple-800 border-purple-200"
                                        : "bg-gray-100 text-gray-800 border-gray-200"
                                  }
                                >
                                  {applicant.status}
                                </Badge>
                              </div>

                              <p className="text-sm text-muted-foreground mb-2">
                                Applied for: {applicant.internshipTitle}
                              </p>

                              <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-3">
                                <div className="flex items-center space-x-1">
                                  <Mail className="w-4 h-4" />
                                  <span>{applicant.email}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Phone className="w-4 h-4" />
                                  <span>{applicant.phone}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Calendar className="w-4 h-4" />
                                  <span>Applied {applicant.appliedDate}</span>
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-2 mb-3">
                                {applicant.skills.map((skill) => (
                                  <Badge key={skill} variant="secondary" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>

                              <div className="text-sm">
                                <p>
                                  <span className="font-medium">Education:</span> {applicant.education} from{" "}
                                  {applicant.college}
                                </p>
                                <p>
                                  <span className="font-medium">Experience:</span> {applicant.experience}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-col space-y-2 ml-4">
                            <Button size="sm" onClick={() => setSelectedApplicant(applicant)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Profile
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleShortlist(applicant.id)}
                              className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Shortlist
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleReject(applicant.id)}
                              className="bg-red-50 text-red-700 border-red-200 hover:bg-red-100"
                            >
                              <X className="w-4 h-4 mr-2" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "analytics" && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Analytics</h2>

                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Applications Received</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{totalApplicants}</div>
                      <p className="text-xs text-green-600">+12% from last month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Shortlist Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {Math.round((totalShortlisted / totalApplicants) * 100)}%
                      </div>
                      <p className="text-xs text-blue-600">Industry average: 15%</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Hire Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{Math.round((totalHired / totalApplicants) * 100)}%</div>
                      <p className="text-xs text-green-600">Above industry average</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground">Avg. Time to Hire</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">14 days</div>
                      <p className="text-xs text-green-600">-3 days from last month</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Skills in Demand</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">React</span>
                          <span className="text-sm font-medium">85%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">JavaScript</span>
                          <span className="text-sm font-medium">78%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Python</span>
                          <span className="text-sm font-medium">65%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Node.js</span>
                          <span className="text-sm font-medium">52%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Application Sources</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Direct Applications</span>
                          <span className="text-sm font-medium">45%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">AI Recommendations</span>
                          <span className="text-sm font-medium">35%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Referrals</span>
                          <span className="text-sm font-medium">15%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Social Media</span>
                          <span className="text-sm font-medium">5%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Applicant Detail Modal */}
        {selectedApplicant && (
          <Dialog open={!!selectedApplicant} onOpenChange={() => setSelectedApplicant(null)}>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={selectedApplicant.avatar || "/placeholder.svg"} />
                    <AvatarFallback>
                      {selectedApplicant.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div>{selectedApplicant.name}</div>
                    <div className="text-sm text-muted-foreground font-normal">{selectedApplicant.internshipTitle}</div>
                  </div>
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Email:</span> {selectedApplicant.email}
                  </div>
                  <div>
                    <span className="font-medium">Phone:</span> {selectedApplicant.phone}
                  </div>
                  <div>
                    <span className="font-medium">Education:</span> {selectedApplicant.education}
                  </div>
                  <div>
                    <span className="font-medium">College:</span> {selectedApplicant.college}
                  </div>
                  <div>
                    <span className="font-medium">Experience:</span> {selectedApplicant.experience}
                  </div>
                  <div>
                    <span className="font-medium">AI Match:</span> {selectedApplicant.aiMatch}%
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedApplicant.skills.map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Cover Letter</h4>
                  <p className="text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg">
                    {selectedApplicant.coverLetter}
                  </p>
                </div>

                <div className="flex justify-between pt-4">
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download Resume
                  </Button>
                  <div className="space-x-2">
                    <Button
                      onClick={() => handleShortlist(selectedApplicant.id)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Shortlist
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleReject(selectedApplicant.id)}
                      className="border-red-200 text-red-700 hover:bg-red-50"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </AuthGuard>
  )
}

export default RecruiterDashboard
