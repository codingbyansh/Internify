"use client"

import { useState } from "react"
import { AuthGuard } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Brain,
  Users,
  Building2,
  TrendingUp,
  BarChart3,
  Activity,
  Award,
  Target,
  Globe,
  Download,
  Settings,
  LogOut,
  MapPin,
  Star,
  ArrowUp,
} from "lucide-react"
import { authService } from "@/lib/auth"
import Link from "next/link"

// Mock data for admin dashboard
const mockStats = {
  totalStudents: 12547,
  totalRecruiters: 1834,
  totalInternships: 3421,
  activeInternships: 2156,
  totalApplications: 45632,
  successfulPlacements: 8934,
  avgMatchScore: 87,
  platformGrowth: 23.5,
}

const mockRecentActivity = [
  {
    id: "1",
    type: "registration",
    message: "New student registered from IIT Delhi",
    timestamp: "2 minutes ago",
    icon: Users,
    color: "text-green-600",
  },
  {
    id: "2",
    type: "internship",
    message: "TechCorp posted new Frontend Developer internship",
    timestamp: "15 minutes ago",
    icon: Building2,
    color: "text-blue-600",
  },
  {
    id: "3",
    type: "application",
    message: "50 new applications received in the last hour",
    timestamp: "1 hour ago",
    icon: TrendingUp,
    color: "text-purple-600",
  },
  {
    id: "4",
    type: "placement",
    message: "Student successfully placed at StartupXYZ",
    timestamp: "2 hours ago",
    icon: Award,
    color: "text-green-600",
  },
]

const mockTopCompanies = [
  {
    name: "TechCorp",
    internships: 45,
    applications: 1234,
    placements: 23,
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=techcorp",
  },
  {
    name: "DataFlow",
    internships: 32,
    applications: 987,
    placements: 18,
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=dataflow",
  },
  {
    name: "CloudTech",
    internships: 28,
    applications: 756,
    placements: 15,
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=cloudtech",
  },
  {
    name: "StartupXYZ",
    internships: 21,
    applications: 543,
    placements: 12,
    logo: "https://api.dicebear.com/7.x/shapes/svg?seed=startupxyz",
  },
]

const mockTopColleges = [
  { name: "IIT Delhi", students: 234, applications: 1876, placements: 89, successRate: 38 },
  { name: "IIT Bombay", students: 198, applications: 1654, placements: 76, successRate: 38 },
  { name: "IIIT Bangalore", students: 156, applications: 1234, placements: 58, successRate: 37 },
  { name: "NIT Trichy", students: 143, applications: 1098, placements: 52, successRate: 36 },
]

const mockRegionalData = [
  { region: "Bangalore", students: 3421, internships: 1234, placements: 456 },
  { region: "Mumbai", students: 2876, internships: 987, placements: 378 },
  { region: "Delhi", students: 2543, internships: 876, placements: 334 },
  { region: "Hyderabad", students: 1987, internships: 654, placements: 267 },
  { region: "Pune", students: 1654, internships: 543, placements: 198 },
]

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [timeRange, setTimeRange] = useState("30d")

  const user = authService.getCurrentUser()

  return (
    <AuthGuard requiredRole="admin">
      <div className="min-h-screen bg-background">
        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-card border-r min-h-screen p-4">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <span className="text-xl font-bold">Internify</span>
                <div className="text-xs text-muted-foreground">Admin Panel</div>
              </div>
            </div>

            <nav className="space-y-2">
              <button
                onClick={() => setActiveTab("overview")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "overview"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>Overview</span>
              </button>
              <button
                onClick={() => setActiveTab("analytics")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "analytics"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <TrendingUp className="w-4 h-4" />
                <span>Analytics</span>
              </button>
              <button
                onClick={() => setActiveTab("users")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "users"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Users</span>
              </button>
              <button
                onClick={() => setActiveTab("internships")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "internships"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span>Internships</span>
              </button>
              <button
                onClick={() => setActiveTab("regional")}
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg w-full text-left ${
                  activeTab === "regional"
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <Globe className="w-4 h-4" />
                <span>Regional Data</span>
              </button>
            </nav>

            <div className="mt-8 pt-8 border-t">
              <nav className="space-y-2">
                <Link
                  href="/dashboard/admin/settings"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted"
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </Link>
                <button
                  onClick={() => {
                    authService.logout()
                    window.location.href = "/"
                  }}
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted w-full text-left"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-balance">SIH 2025 Admin Dashboard</h1>
                <p className="text-muted-foreground mt-1">Monitor platform performance and engagement metrics</p>
              </div>
              <div className="flex items-center space-x-4">
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">Last 7 days</SelectItem>
                    <SelectItem value="30d">Last 30 days</SelectItem>
                    <SelectItem value="90d">Last 90 days</SelectItem>
                    <SelectItem value="1y">Last year</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
                </Button>
                <Avatar>
                  <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                  <AvatarFallback>
                    {user?.firstName?.[0]}
                    {user?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>

            {/* Content based on active tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* Key Metrics */}
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                        Total Students
                        <ArrowUp className="w-4 h-4 text-green-500" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{mockStats.totalStudents.toLocaleString()}</div>
                      <p className="text-xs text-green-600">+12.5% from last month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                        Active Recruiters
                        <ArrowUp className="w-4 h-4 text-green-500" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{mockStats.totalRecruiters.toLocaleString()}</div>
                      <p className="text-xs text-green-600">+8.3% from last month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                        Total Internships
                        <ArrowUp className="w-4 h-4 text-green-500" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{mockStats.totalInternships.toLocaleString()}</div>
                      <p className="text-xs text-green-600">+15.7% from last month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                        Successful Placements
                        <ArrowUp className="w-4 h-4 text-green-500" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{mockStats.successfulPlacements.toLocaleString()}</div>
                      <p className="text-xs text-green-600">+22.1% from last month</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Platform Health */}
                <div className="grid md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Activity className="w-5 h-5 text-primary" />
                        <span>Platform Health</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>System Uptime</span>
                            <span className="font-medium">99.9%</span>
                          </div>
                          <Progress value={99.9} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>API Response Time</span>
                            <span className="font-medium">145ms</span>
                          </div>
                          <Progress value={85} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>User Satisfaction</span>
                            <span className="font-medium">4.8/5</span>
                          </div>
                          <Progress value={96} className="h-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Target className="w-5 h-5 text-accent" />
                        <span>AI Performance</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Avg Match Score</span>
                            <span className="font-medium">{mockStats.avgMatchScore}%</span>
                          </div>
                          <Progress value={mockStats.avgMatchScore} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Recommendation Accuracy</span>
                            <span className="font-medium">92%</span>
                          </div>
                          <Progress value={92} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Placement Success Rate</span>
                            <span className="font-medium">19.6%</span>
                          </div>
                          <Progress value={78} className="h-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <TrendingUp className="w-5 h-5 text-secondary" />
                        <span>Growth Metrics</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Monthly Active Users</span>
                          <div className="flex items-center space-x-1">
                            <ArrowUp className="w-3 h-3 text-green-500" />
                            <span className="text-sm font-medium">+18.5%</span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Application Volume</span>
                          <div className="flex items-center space-x-1">
                            <ArrowUp className="w-3 h-3 text-green-500" />
                            <span className="text-sm font-medium">+25.3%</span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Platform Engagement</span>
                          <div className="flex items-center space-x-1">
                            <ArrowUp className="w-3 h-3 text-green-500" />
                            <span className="text-sm font-medium">+14.7%</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recent Activity */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Platform Activity</CardTitle>
                    <CardDescription>Real-time updates from across the platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockRecentActivity.map((activity) => (
                        <div key={activity.id} className="flex items-center space-x-3">
                          <div
                            className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center ${activity.color}`}
                          >
                            <activity.icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">{activity.message}</p>
                            <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === "analytics" && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Performing Companies</CardTitle>
                      <CardDescription>Companies with highest engagement</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {mockTopCompanies.map((company, index) => (
                          <div key={company.name} className="flex items-center space-x-3">
                            <div className="flex items-center space-x-2 flex-1">
                              <span className="text-sm font-medium text-muted-foreground w-4">#{index + 1}</span>
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={company.logo || "/placeholder.svg"} />
                                <AvatarFallback>{company.name[0]}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{company.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {company.internships} internships • {company.placements} placements
                                </p>
                              </div>
                            </div>
                            <Badge variant="secondary">{company.applications} apps</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Top Colleges</CardTitle>
                      <CardDescription>Colleges with highest placement rates</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {mockTopColleges.map((college, index) => (
                          <div key={college.name} className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="text-sm font-medium text-muted-foreground w-4">#{index + 1}</span>
                              <div>
                                <p className="text-sm font-medium">{college.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {college.students} students • {college.placements} placed
                                </p>
                              </div>
                            </div>
                            <Badge className="bg-green-100 text-green-800 border-green-200">
                              {college.successRate}%
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Application Trends</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">This Week</span>
                          <span className="text-sm font-medium">2,847</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Last Week</span>
                          <span className="text-sm font-medium">2,234</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Growth</span>
                          <div className="flex items-center space-x-1">
                            <ArrowUp className="w-3 h-3 text-green-500" />
                            <span className="text-sm font-medium text-green-600">+27.4%</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Popular Skills</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>React</span>
                          <span className="font-medium">1,234</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Python</span>
                          <span className="font-medium">987</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>JavaScript</span>
                          <span className="font-medium">876</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Java</span>
                          <span className="font-medium">654</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Success Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Interview Rate</span>
                          <span className="text-sm font-medium">34.2%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Offer Rate</span>
                          <span className="text-sm font-medium">19.6%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Acceptance Rate</span>
                          <span className="text-sm font-medium">87.3%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {activeTab === "regional" && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Regional Distribution</CardTitle>
                    <CardDescription>Platform usage across different regions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockRegionalData.map((region) => (
                        <div key={region.region} className="grid grid-cols-4 gap-4 p-4 border rounded-lg">
                          <div>
                            <div className="flex items-center space-x-2 mb-2">
                              <MapPin className="w-4 h-4 text-primary" />
                              <span className="font-medium">{region.region}</span>
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold">{region.students.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">Students</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold">{region.internships.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">Internships</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold">{region.placements.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">Placements</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Government Partners Section */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="w-5 h-5 text-primary" />
                  <span>Government Partners & References</span>
                </CardTitle>
                <CardDescription>SIH 2025 supported by Government of India initiatives</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Award className="w-8 h-8 text-primary" />
                    </div>
                    <h4 className="font-medium mb-1">PM Internship Scheme</h4>
                    <p className="text-xs text-muted-foreground">Government backing for internship opportunities</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Building2 className="w-8 h-8 text-accent" />
                    </div>
                    <h4 className="font-medium mb-1">NASSCOM</h4>
                    <p className="text-xs text-muted-foreground">Industry partnership and support</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Globe className="w-8 h-8 text-secondary" />
                    </div>
                    <h4 className="font-medium mb-1">World Bank</h4>
                    <p className="text-xs text-muted-foreground">International development support</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Star className="w-8 h-8 text-primary" />
                    </div>
                    <h4 className="font-medium mb-1">IEEE/ACM</h4>
                    <p className="text-xs text-muted-foreground">Technical standards and excellence</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AuthGuard>
  )
}

export default AdminDashboard
